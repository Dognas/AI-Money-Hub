export type FieldType = "number" | "currency" | "percent"

export type Field = {
  key: string
  label: string
  type: FieldType
  default: number
  min?: number
  max?: number
  step?: number
  suffix?: string
}

export type ResultRow = {
  label: string
  value: string
  highlight?: boolean
  hint?: string
}

export type Calculator = {
  intro: string
  fields: Field[]
  compute: (v: Record<string, number>) => ResultRow[]
}

const usd = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(isFinite(n) ? n : 0)

const usd2 = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  }).format(isFinite(n) ? n : 0)

const pct = (n: number) => `${(isFinite(n) ? n : 0).toFixed(2)}%`
const num = (n: number, d = 0) => (isFinite(n) ? n : 0).toLocaleString("en-US", { maximumFractionDigits: d })

// Standard amortized monthly payment
function monthlyPayment(principal: number, annualRate: number, years: number) {
  const r = annualRate / 100 / 12
  const n = years * 12
  if (r === 0) return n ? principal / n : 0
  return (principal * r) / (1 - Math.pow(1 + r, -n))
}

// Simplified progressive US federal tax (2024 single brackets)
function federalTax(taxable: number) {
  const brackets = [
    [0, 0.1],
    [11600, 0.12],
    [47150, 0.22],
    [100525, 0.24],
    [191950, 0.32],
    [243725, 0.35],
    [609350, 0.37],
  ]
  let tax = 0
  for (let i = 0; i < brackets.length; i++) {
    const [floor, rate] = brackets[i]
    const ceil = i < brackets.length - 1 ? brackets[i + 1][0] : Infinity
    if (taxable > floor) {
      tax += (Math.min(taxable, ceil) - floor) * rate
    } else break
  }
  return tax
}

export const calculators: Record<string, Calculator> = {
  salary: {
    intro: "Convert your pay between annual, monthly, weekly, and hourly figures.",
    fields: [
      { key: "annual", label: "Annual Salary", type: "currency", default: 75000 },
      { key: "hoursPerWeek", label: "Hours / Week", type: "number", default: 40, suffix: "hrs" },
      { key: "weeksPerYear", label: "Weeks / Year", type: "number", default: 52, suffix: "wks" },
    ],
    compute: (v) => {
      const annual = v.annual
      const hours = v.hoursPerWeek * v.weeksPerYear
      return [
        { label: "Annual", value: usd(annual), highlight: true },
        { label: "Monthly", value: usd(annual / 12) },
        { label: "Bi-Weekly", value: usd(annual / 26) },
        { label: "Weekly", value: usd(annual / v.weeksPerYear) },
        { label: "Daily (5-day)", value: usd2(annual / (v.weeksPerYear * 5)) },
        { label: "Hourly", value: usd2(annual / hours) },
      ]
    },
  },
  "hourly-to-salary": {
    intro: "Turn your hourly wage into an estimated yearly income.",
    fields: [
      { key: "rate", label: "Hourly Rate", type: "currency", default: 25 },
      { key: "hoursPerWeek", label: "Hours / Week", type: "number", default: 40, suffix: "hrs" },
      { key: "weeksPerYear", label: "Weeks / Year", type: "number", default: 52, suffix: "wks" },
    ],
    compute: (v) => {
      const annual = v.rate * v.hoursPerWeek * v.weeksPerYear
      return [
        { label: "Annual Salary", value: usd(annual), highlight: true },
        { label: "Monthly", value: usd(annual / 12) },
        { label: "Weekly", value: usd(v.rate * v.hoursPerWeek) },
      ]
    },
  },
  "take-home-pay": {
    intro: "Estimate your net paycheck after federal tax and typical deductions.",
    fields: [
      { key: "annual", label: "Gross Annual Salary", type: "currency", default: 75000 },
      { key: "pretax", label: "Pre-tax Deductions / Year", type: "currency", default: 6000 },
      { key: "stateRate", label: "State Tax Rate", type: "percent", default: 5 },
    ],
    compute: (v) => {
      const taxable = Math.max(0, v.annual - v.pretax - 14600)
      const fed = federalTax(taxable)
      const fica = v.annual * 0.0765
      const state = (v.annual - v.pretax) * (v.stateRate / 100)
      const net = v.annual - v.pretax - fed - fica - state
      return [
        { label: "Net Take-Home (Year)", value: usd(net), highlight: true },
        { label: "Net Monthly", value: usd(net / 12) },
        { label: "Federal Tax", value: usd(fed) },
        { label: "FICA (Soc. Sec + Medicare)", value: usd(fica) },
        { label: "State Tax", value: usd(state) },
        { label: "Effective Tax Rate", value: pct(((fed + fica + state) / v.annual) * 100) },
      ]
    },
  },
  overtime: {
    intro: "Calculate overtime pay at time-and-a-half plus your base pay.",
    fields: [
      { key: "rate", label: "Base Hourly Rate", type: "currency", default: 25 },
      { key: "regular", label: "Regular Hours", type: "number", default: 40, suffix: "hrs" },
      { key: "ot", label: "Overtime Hours", type: "number", default: 10, suffix: "hrs" },
      { key: "multiplier", label: "OT Multiplier", type: "number", default: 1.5, step: 0.5 },
    ],
    compute: (v) => {
      const base = v.rate * v.regular
      const otPay = v.rate * v.multiplier * v.ot
      return [
        { label: "Total Weekly Pay", value: usd2(base + otPay), highlight: true },
        { label: "Regular Pay", value: usd2(base) },
        { label: "Overtime Pay", value: usd2(otPay) },
        { label: "OT Hourly Rate", value: usd2(v.rate * v.multiplier) },
      ]
    },
  },
  raise: {
    intro: "See your new salary and the difference after a percentage raise.",
    fields: [
      { key: "current", label: "Current Salary", type: "currency", default: 75000 },
      { key: "raise", label: "Raise", type: "percent", default: 5 },
    ],
    compute: (v) => {
      const newSalary = v.current * (1 + v.raise / 100)
      return [
        { label: "New Salary", value: usd(newSalary), highlight: true },
        { label: "Annual Increase", value: usd(newSalary - v.current) },
        { label: "Monthly Increase", value: usd((newSalary - v.current) / 12) },
      ]
    },
  },
  "gross-to-net": {
    intro: "Break down gross income into estimated net take-home pay.",
    fields: [
      { key: "gross", label: "Gross Income", type: "currency", default: 6000 },
      { key: "taxRate", label: "Total Tax Rate", type: "percent", default: 25 },
    ],
    compute: (v) => {
      const tax = v.gross * (v.taxRate / 100)
      return [
        { label: "Net Income", value: usd(v.gross - tax), highlight: true },
        { label: "Total Tax", value: usd(tax) },
      ]
    },
  },
  "cost-of-living": {
    intro: "Find the equivalent salary needed in a city with a different cost of living.",
    fields: [
      { key: "salary", label: "Current Salary", type: "currency", default: 75000 },
      { key: "indexDiff", label: "Cost Difference", type: "percent", default: 20, suffix: "% higher" },
    ],
    compute: (v) => {
      const needed = v.salary * (1 + v.indexDiff / 100)
      return [
        { label: "Equivalent Salary Needed", value: usd(needed), highlight: true },
        { label: "Extra Required", value: usd(needed - v.salary) },
      ]
    },
  },
  "annual-bonus": {
    intro: "Estimate your bonus payout and after-tax amount.",
    fields: [
      { key: "salary", label: "Base Salary", type: "currency", default: 75000 },
      { key: "bonusPct", label: "Bonus Target", type: "percent", default: 10 },
      { key: "taxRate", label: "Bonus Tax Rate", type: "percent", default: 22 },
    ],
    compute: (v) => {
      const bonus = v.salary * (v.bonusPct / 100)
      const net = bonus * (1 - v.taxRate / 100)
      return [
        { label: "Net Bonus", value: usd(net), highlight: true },
        { label: "Gross Bonus", value: usd(bonus) },
        { label: "Tax Withheld", value: usd(bonus - net) },
      ]
    },
  },

  "income-tax": {
    intro: "Estimate federal income tax using 2024 single-filer brackets.",
    fields: [
      { key: "income", label: "Annual Income", type: "currency", default: 75000 },
      { key: "deductions", label: "Deductions", type: "currency", default: 14600 },
    ],
    compute: (v) => {
      const taxable = Math.max(0, v.income - v.deductions)
      const tax = federalTax(taxable)
      return [
        { label: "Estimated Federal Tax", value: usd(tax), highlight: true },
        { label: "Taxable Income", value: usd(taxable) },
        { label: "After-Tax Income", value: usd(v.income - tax) },
        { label: "Effective Rate", value: pct((tax / v.income) * 100) },
      ]
    },
  },
  "sales-tax": {
    intro: "Add sales tax to a purchase to find the total cost.",
    fields: [
      { key: "amount", label: "Purchase Amount", type: "currency", default: 100 },
      { key: "rate", label: "Sales Tax Rate", type: "percent", default: 8.25 },
    ],
    compute: (v) => {
      const tax = v.amount * (v.rate / 100)
      return [
        { label: "Total With Tax", value: usd2(v.amount + tax), highlight: true },
        { label: "Tax Amount", value: usd2(tax) },
      ]
    },
  },
  vat: {
    intro: "Add or remove value-added tax from a price.",
    fields: [
      { key: "amount", label: "Net Amount", type: "currency", default: 100 },
      { key: "rate", label: "VAT Rate", type: "percent", default: 20 },
    ],
    compute: (v) => {
      const vatAmt = v.amount * (v.rate / 100)
      return [
        { label: "Gross (incl. VAT)", value: usd2(v.amount + vatAmt), highlight: true },
        { label: "VAT Amount", value: usd2(vatAmt) },
        { label: "Net Amount", value: usd2(v.amount) },
      ]
    },
  },
  "capital-gains": {
    intro: "Estimate tax owed on profit from selling an asset.",
    fields: [
      { key: "buy", label: "Purchase Price", type: "currency", default: 10000 },
      { key: "sell", label: "Sale Price", type: "currency", default: 15000 },
      { key: "rate", label: "Capital Gains Rate", type: "percent", default: 15 },
    ],
    compute: (v) => {
      const gain = v.sell - v.buy
      const tax = Math.max(0, gain) * (v.rate / 100)
      return [
        { label: "Capital Gains Tax", value: usd(tax), highlight: true },
        { label: "Total Gain", value: usd(gain) },
        { label: "Net Profit", value: usd(gain - tax) },
      ]
    },
  },
  "self-employment-tax": {
    intro: "Estimate self-employment tax (15.3%) for freelancers.",
    fields: [{ key: "netProfit", label: "Net Business Profit", type: "currency", default: 60000 }],
    compute: (v) => {
      const base = v.netProfit * 0.9235
      const seTax = base * 0.153
      return [
        { label: "Self-Employment Tax", value: usd(seTax), highlight: true },
        { label: "Deductible Half", value: usd(seTax / 2) },
        { label: "Taxable Base", value: usd(base) },
      ]
    },
  },
  "property-tax": {
    intro: "Estimate annual property tax from your home value.",
    fields: [
      { key: "value", label: "Home Value", type: "currency", default: 400000 },
      { key: "rate", label: "Property Tax Rate", type: "percent", default: 1.1 },
    ],
    compute: (v) => {
      const tax = v.value * (v.rate / 100)
      return [
        { label: "Annual Property Tax", value: usd(tax), highlight: true },
        { label: "Monthly", value: usd(tax / 12) },
      ]
    },
  },
  "tax-refund": {
    intro: "Estimate your refund or balance due based on withholding.",
    fields: [
      { key: "income", label: "Annual Income", type: "currency", default: 75000 },
      { key: "withheld", label: "Tax Withheld", type: "currency", default: 12000 },
      { key: "deductions", label: "Deductions", type: "currency", default: 14600 },
    ],
    compute: (v) => {
      const tax = federalTax(Math.max(0, v.income - v.deductions))
      const diff = v.withheld - tax
      return [
        { label: diff >= 0 ? "Estimated Refund" : "Balance Due", value: usd(Math.abs(diff)), highlight: true },
        { label: "Tax Owed", value: usd(tax) },
        { label: "Total Withheld", value: usd(v.withheld) },
      ]
    },
  },
  tip: {
    intro: "Calculate the tip and split the bill among friends.",
    fields: [
      { key: "bill", label: "Bill Amount", type: "currency", default: 80 },
      { key: "tipPct", label: "Tip", type: "percent", default: 18 },
      { key: "people", label: "Split Between", type: "number", default: 2, min: 1, suffix: "people" },
    ],
    compute: (v) => {
      const tip = v.bill * (v.tipPct / 100)
      const total = v.bill + tip
      return [
        { label: "Per Person", value: usd2(total / Math.max(1, v.people)), highlight: true },
        { label: "Total Bill", value: usd2(total) },
        { label: "Tip Amount", value: usd2(tip) },
      ]
    },
  },

  "compound-interest": {
    intro: "See how an investment grows with compound interest.",
    fields: [
      { key: "principal", label: "Initial Amount", type: "currency", default: 10000 },
      { key: "rate", label: "Annual Return", type: "percent", default: 8 },
      { key: "years", label: "Years", type: "number", default: 20, suffix: "yrs" },
      { key: "compounds", label: "Compounds / Year", type: "number", default: 12 },
    ],
    compute: (v) => {
      const n = v.compounds
      const amount = v.principal * Math.pow(1 + v.rate / 100 / n, n * v.years)
      return [
        { label: "Future Value", value: usd(amount), highlight: true },
        { label: "Total Interest", value: usd(amount - v.principal) },
        { label: "Initial Investment", value: usd(v.principal) },
      ]
    },
  },
  roi: {
    intro: "Calculate the return on investment as a percentage.",
    fields: [
      { key: "cost", label: "Initial Cost", type: "currency", default: 5000 },
      { key: "final", label: "Final Value", type: "currency", default: 8000 },
    ],
    compute: (v) => {
      const profit = v.final - v.cost
      return [
        { label: "ROI", value: pct((profit / v.cost) * 100), highlight: true },
        { label: "Net Profit", value: usd(profit) },
      ]
    },
  },
  "investment-growth": {
    intro: "Project growth combining an initial amount with monthly contributions.",
    fields: [
      { key: "principal", label: "Initial Amount", type: "currency", default: 5000 },
      { key: "monthly", label: "Monthly Contribution", type: "currency", default: 500 },
      { key: "rate", label: "Annual Return", type: "percent", default: 8 },
      { key: "years", label: "Years", type: "number", default: 20, suffix: "yrs" },
    ],
    compute: (v) => {
      const r = v.rate / 100 / 12
      const n = v.years * 12
      const fvPrincipal = v.principal * Math.pow(1 + r, n)
      const fvContrib = r === 0 ? v.monthly * n : v.monthly * ((Math.pow(1 + r, n) - 1) / r)
      const total = fvPrincipal + fvContrib
      const invested = v.principal + v.monthly * n
      return [
        { label: "Future Value", value: usd(total), highlight: true },
        { label: "Total Invested", value: usd(invested) },
        { label: "Total Growth", value: usd(total - invested) },
      ]
    },
  },
  dividend: {
    intro: "Estimate annual income from dividend-paying stocks.",
    fields: [
      { key: "invested", label: "Amount Invested", type: "currency", default: 50000 },
      { key: "yield", label: "Dividend Yield", type: "percent", default: 4 },
    ],
    compute: (v) => {
      const annual = v.invested * (v.yield / 100)
      return [
        { label: "Annual Dividend Income", value: usd(annual), highlight: true },
        { label: "Monthly", value: usd(annual / 12) },
        { label: "Quarterly", value: usd(annual / 4) },
      ]
    },
  },
  dca: {
    intro: "Project results of investing a fixed amount on a recurring schedule.",
    fields: [
      { key: "monthly", label: "Monthly Investment", type: "currency", default: 300 },
      { key: "rate", label: "Annual Return", type: "percent", default: 8 },
      { key: "years", label: "Years", type: "number", default: 10, suffix: "yrs" },
    ],
    compute: (v) => {
      const r = v.rate / 100 / 12
      const n = v.years * 12
      const fv = r === 0 ? v.monthly * n : v.monthly * ((Math.pow(1 + r, n) - 1) / r)
      return [
        { label: "Future Value", value: usd(fv), highlight: true },
        { label: "Total Invested", value: usd(v.monthly * n) },
        { label: "Total Gains", value: usd(fv - v.monthly * n) },
      ]
    },
  },
  "stock-return": {
    intro: "Calculate total return from buying and selling shares.",
    fields: [
      { key: "shares", label: "Number of Shares", type: "number", default: 100 },
      { key: "buy", label: "Buy Price / Share", type: "currency", default: 50 },
      { key: "sell", label: "Sell Price / Share", type: "currency", default: 75 },
    ],
    compute: (v) => {
      const cost = v.shares * v.buy
      const proceeds = v.shares * v.sell
      const profit = proceeds - cost
      return [
        { label: "Total Profit", value: usd(profit), highlight: true },
        { label: "Return", value: pct((profit / cost) * 100) },
        { label: "Total Proceeds", value: usd(proceeds) },
      ]
    },
  },
  "401k": {
    intro: "Project 401(k) growth including employer match.",
    fields: [
      { key: "salary", label: "Annual Salary", type: "currency", default: 75000 },
      { key: "contribPct", label: "Your Contribution", type: "percent", default: 6 },
      { key: "matchPct", label: "Employer Match", type: "percent", default: 3 },
      { key: "rate", label: "Annual Return", type: "percent", default: 7 },
      { key: "years", label: "Years", type: "number", default: 30, suffix: "yrs" },
    ],
    compute: (v) => {
      const annualContrib = v.salary * (v.contribPct / 100) + v.salary * (v.matchPct / 100)
      const monthly = annualContrib / 12
      const r = v.rate / 100 / 12
      const n = v.years * 12
      const fv = r === 0 ? monthly * n : monthly * ((Math.pow(1 + r, n) - 1) / r)
      return [
        { label: "401(k) Balance", value: usd(fv), highlight: true },
        { label: "Annual Contribution", value: usd(annualContrib) },
        { label: "Total Contributed", value: usd(annualContrib * v.years) },
      ]
    },
  },
  "rule-of-72": {
    intro: "Estimate how many years it takes to double your money.",
    fields: [{ key: "rate", label: "Annual Return", type: "percent", default: 8 }],
    compute: (v) => [
      { label: "Years to Double", value: `${(72 / v.rate).toFixed(1)} yrs`, highlight: true },
      { label: "Years to Triple", value: `${(114 / v.rate).toFixed(1)} yrs` },
    ],
  },

  mortgage: {
    intro: "Estimate your monthly mortgage payment and total interest.",
    fields: [
      { key: "price", label: "Home Price", type: "currency", default: 400000 },
      { key: "down", label: "Down Payment", type: "currency", default: 80000 },
      { key: "rate", label: "Interest Rate", type: "percent", default: 6.5 },
      { key: "years", label: "Loan Term", type: "number", default: 30, suffix: "yrs" },
    ],
    compute: (v) => {
      const principal = v.price - v.down
      const m = monthlyPayment(principal, v.rate, v.years)
      const total = m * v.years * 12
      return [
        { label: "Monthly Payment", value: usd2(m), highlight: true },
        { label: "Loan Amount", value: usd(principal) },
        { label: "Total Interest", value: usd(total - principal) },
        { label: "Total Paid", value: usd(total) },
      ]
    },
  },
  "auto-loan": {
    intro: "Estimate the monthly payment for a car loan.",
    fields: [
      { key: "price", label: "Vehicle Price", type: "currency", default: 35000 },
      { key: "down", label: "Down Payment", type: "currency", default: 5000 },
      { key: "rate", label: "Interest Rate", type: "percent", default: 7 },
      { key: "years", label: "Term", type: "number", default: 5, suffix: "yrs" },
    ],
    compute: (v) => {
      const principal = v.price - v.down
      const m = monthlyPayment(principal, v.rate, v.years)
      return [
        { label: "Monthly Payment", value: usd2(m), highlight: true },
        { label: "Total Interest", value: usd(m * v.years * 12 - principal) },
        { label: "Total Cost", value: usd(m * v.years * 12 + v.down) },
      ]
    },
  },
  "personal-loan": {
    intro: "Calculate payments and total cost of a personal loan.",
    fields: [
      { key: "amount", label: "Loan Amount", type: "currency", default: 15000 },
      { key: "rate", label: "Interest Rate", type: "percent", default: 11 },
      { key: "years", label: "Term", type: "number", default: 3, suffix: "yrs" },
    ],
    compute: (v) => {
      const m = monthlyPayment(v.amount, v.rate, v.years)
      return [
        { label: "Monthly Payment", value: usd2(m), highlight: true },
        { label: "Total Interest", value: usd(m * v.years * 12 - v.amount) },
        { label: "Total Repaid", value: usd(m * v.years * 12) },
      ]
    },
  },
  "student-loan": {
    intro: "Estimate student loan repayment and total cost.",
    fields: [
      { key: "amount", label: "Loan Balance", type: "currency", default: 30000 },
      { key: "rate", label: "Interest Rate", type: "percent", default: 5.5 },
      { key: "years", label: "Repayment Term", type: "number", default: 10, suffix: "yrs" },
    ],
    compute: (v) => {
      const m = monthlyPayment(v.amount, v.rate, v.years)
      return [
        { label: "Monthly Payment", value: usd2(m), highlight: true },
        { label: "Total Interest", value: usd(m * v.years * 12 - v.amount) },
        { label: "Total Paid", value: usd(m * v.years * 12) },
      ]
    },
  },
  "credit-card-payoff": {
    intro: "See how long it takes to pay off a credit card balance.",
    fields: [
      { key: "balance", label: "Card Balance", type: "currency", default: 5000 },
      { key: "apr", label: "APR", type: "percent", default: 22 },
      { key: "payment", label: "Monthly Payment", type: "currency", default: 200 },
    ],
    compute: (v) => {
      const r = v.apr / 100 / 12
      let bal = v.balance
      let months = 0
      let interest = 0
      while (bal > 0 && months < 1200) {
        const i = bal * r
        interest += i
        bal = bal + i - v.payment
        months++
        if (v.payment <= v.balance * r) break
      }
      const ok = months < 1200 && bal <= 0
      return [
        { label: "Time to Pay Off", value: ok ? `${Math.floor(months / 12)}y ${months % 12}m` : "Never (payment too low)", highlight: true },
        { label: "Total Interest", value: ok ? usd(interest) : "—" },
        { label: "Total Paid", value: ok ? usd(v.balance + interest) : "—" },
      ]
    },
  },
  "debt-payoff": {
    intro: "Find out how many months until you're debt-free.",
    fields: [
      { key: "balance", label: "Total Debt", type: "currency", default: 12000 },
      { key: "rate", label: "Average APR", type: "percent", default: 15 },
      { key: "payment", label: "Monthly Payment", type: "currency", default: 400 },
    ],
    compute: (v) => {
      const r = v.rate / 100 / 12
      let bal = v.balance
      let months = 0
      let interest = 0
      while (bal > 0 && months < 1200) {
        const i = bal * r
        interest += i
        bal = bal + i - v.payment
        months++
        if (v.payment <= v.balance * r) break
      }
      const ok = months < 1200 && bal <= 0
      return [
        { label: "Debt-Free In", value: ok ? `${Math.floor(months / 12)}y ${months % 12}m` : "Increase payment", highlight: true },
        { label: "Total Interest", value: ok ? usd(interest) : "—" },
      ]
    },
  },
  "loan-amortization": {
    intro: "Break down a loan into principal, interest, and total cost.",
    fields: [
      { key: "amount", label: "Loan Amount", type: "currency", default: 200000 },
      { key: "rate", label: "Interest Rate", type: "percent", default: 6 },
      { key: "years", label: "Term", type: "number", default: 30, suffix: "yrs" },
    ],
    compute: (v) => {
      const m = monthlyPayment(v.amount, v.rate, v.years)
      const total = m * v.years * 12
      return [
        { label: "Monthly Payment", value: usd2(m), highlight: true },
        { label: "Total Principal", value: usd(v.amount) },
        { label: "Total Interest", value: usd(total - v.amount) },
        { label: "Total of Payments", value: usd(total) },
      ]
    },
  },
  refinance: {
    intro: "Compare your current loan with a refinanced one.",
    fields: [
      { key: "balance", label: "Loan Balance", type: "currency", default: 250000 },
      { key: "oldRate", label: "Current Rate", type: "percent", default: 7 },
      { key: "newRate", label: "New Rate", type: "percent", default: 5.5 },
      { key: "years", label: "Years Remaining", type: "number", default: 25, suffix: "yrs" },
    ],
    compute: (v) => {
      const oldM = monthlyPayment(v.balance, v.oldRate, v.years)
      const newM = monthlyPayment(v.balance, v.newRate, v.years)
      return [
        { label: "Monthly Savings", value: usd2(oldM - newM), highlight: true },
        { label: "New Payment", value: usd2(newM) },
        { label: "Lifetime Savings", value: usd((oldM - newM) * v.years * 12) },
      ]
    },
  },

  "savings-goal": {
    intro: "Find how much to save each month to reach your goal.",
    fields: [
      { key: "goal", label: "Savings Goal", type: "currency", default: 20000 },
      { key: "current", label: "Already Saved", type: "currency", default: 2000 },
      { key: "months", label: "Months to Goal", type: "number", default: 24, suffix: "mo" },
      { key: "rate", label: "Annual Interest", type: "percent", default: 4 },
    ],
    compute: (v) => {
      const r = v.rate / 100 / 12
      const remaining = v.goal - v.current * Math.pow(1 + r, v.months)
      const monthly = r === 0 ? remaining / v.months : (remaining * r) / (Math.pow(1 + r, v.months) - 1)
      return [
        { label: "Monthly Savings Needed", value: usd2(Math.max(0, monthly)), highlight: true },
        { label: "Amount to Save", value: usd(v.goal - v.current) },
      ]
    },
  },
  "emergency-fund": {
    intro: "Calculate the emergency fund you should keep on hand.",
    fields: [
      { key: "expenses", label: "Monthly Expenses", type: "currency", default: 3500 },
      { key: "months", label: "Months of Coverage", type: "number", default: 6, suffix: "mo" },
      { key: "saved", label: "Already Saved", type: "currency", default: 5000 },
    ],
    compute: (v) => {
      const target = v.expenses * v.months
      return [
        { label: "Target Fund", value: usd(target), highlight: true },
        { label: "Still Needed", value: usd(Math.max(0, target - v.saved)) },
        { label: "Coverage Now", value: `${(v.saved / v.expenses).toFixed(1)} months` },
      ]
    },
  },
  "budget-50-30-20": {
    intro: "Split your take-home pay into needs, wants, and savings.",
    fields: [{ key: "income", label: "Monthly Take-Home", type: "currency", default: 5000 }],
    compute: (v) => [
      { label: "Needs (50%)", value: usd(v.income * 0.5), highlight: true },
      { label: "Wants (30%)", value: usd(v.income * 0.3) },
      { label: "Savings (20%)", value: usd(v.income * 0.2) },
    ],
  },
  "net-worth": {
    intro: "Calculate your net worth as assets minus liabilities.",
    fields: [
      { key: "assets", label: "Total Assets", type: "currency", default: 350000 },
      { key: "liabilities", label: "Total Liabilities", type: "currency", default: 120000 },
    ],
    compute: (v) => [
      { label: "Net Worth", value: usd(v.assets - v.liabilities), highlight: true },
      { label: "Total Assets", value: usd(v.assets) },
      { label: "Total Liabilities", value: usd(v.liabilities) },
    ],
  },
  "fire-number": {
    intro: "Estimate the nest egg needed to retire early (4% rule).",
    fields: [
      { key: "spending", label: "Annual Spending", type: "currency", default: 50000 },
      { key: "withdrawal", label: "Withdrawal Rate", type: "percent", default: 4 },
    ],
    compute: (v) => {
      const fire = v.spending / (v.withdrawal / 100)
      return [
        { label: "FIRE Number", value: usd(fire), highlight: true },
        { label: "Monthly Passive Income", value: usd(v.spending / 12) },
      ]
    },
  },
  inflation: {
    intro: "See the future cost of money after inflation.",
    fields: [
      { key: "amount", label: "Today's Amount", type: "currency", default: 10000 },
      { key: "rate", label: "Inflation Rate", type: "percent", default: 3 },
      { key: "years", label: "Years", type: "number", default: 20, suffix: "yrs" },
    ],
    compute: (v) => {
      const future = v.amount * Math.pow(1 + v.rate / 100, v.years)
      const buying = v.amount / Math.pow(1 + v.rate / 100, v.years)
      return [
        { label: "Future Cost", value: usd(future), highlight: true },
        { label: "Future Buying Power", value: usd(buying) },
      ]
    },
  },
  "savings-interest": {
    intro: "Calculate interest earned on a savings account.",
    fields: [
      { key: "principal", label: "Balance", type: "currency", default: 10000 },
      { key: "apy", label: "APY", type: "percent", default: 4.5 },
      { key: "years", label: "Years", type: "number", default: 5, suffix: "yrs" },
    ],
    compute: (v) => {
      const fv = v.principal * Math.pow(1 + v.apy / 100, v.years)
      return [
        { label: "Final Balance", value: usd(fv), highlight: true },
        { label: "Interest Earned", value: usd(fv - v.principal) },
      ]
    },
  },

  "tiktok-money": {
    intro: "Estimate TikTok Creator earnings from your views.",
    fields: [
      { key: "views", label: "Monthly Views", type: "number", default: 1000000, suffix: "views" },
      { key: "rpm", label: "RPM (per 1k views)", type: "currency", default: 0.04, step: 0.01 },
    ],
    compute: (v) => {
      const monthly = (v.views / 1000) * v.rpm
      return [
        { label: "Monthly Earnings", value: usd2(monthly), highlight: true },
        { label: "Yearly Estimate", value: usd(monthly * 12) },
      ]
    },
  },
  "youtube-money": {
    intro: "Estimate YouTube ad revenue from views and CPM.",
    fields: [
      { key: "views", label: "Monthly Views", type: "number", default: 500000, suffix: "views" },
      { key: "cpm", label: "CPM", type: "currency", default: 5 },
      { key: "fillRate", label: "Monetized Views", type: "percent", default: 60 },
    ],
    compute: (v) => {
      const monetized = v.views * (v.fillRate / 100)
      const gross = (monetized / 1000) * v.cpm
      const net = gross * 0.55 // YouTube takes 45%
      return [
        { label: "Your Revenue (55%)", value: usd2(net), highlight: true },
        { label: "Gross Ad Revenue", value: usd2(gross) },
        { label: "Yearly Estimate", value: usd(net * 12) },
      ]
    },
  },
  "instagram-earnings": {
    intro: "Estimate a sponsored post rate from your following.",
    fields: [
      { key: "followers", label: "Followers", type: "number", default: 50000, suffix: "followers" },
      { key: "engagement", label: "Engagement Rate", type: "percent", default: 3 },
    ],
    compute: (v) => {
      // ~$10 per 1k followers, adjusted by engagement
      const base = (v.followers / 1000) * 10 * (v.engagement / 3)
      return [
        { label: "Per Sponsored Post", value: usd(base), highlight: true },
        { label: "Per Story", value: usd(base * 0.4) },
        { label: "Monthly (4 posts)", value: usd(base * 4) },
      ]
    },
  },
  "twitch-income": {
    intro: "Estimate Twitch income from subscriptions and bits.",
    fields: [
      { key: "subs", label: "Subscribers", type: "number", default: 200, suffix: "subs" },
      { key: "bits", label: "Monthly Bits", type: "number", default: 50000, suffix: "bits" },
    ],
    compute: (v) => {
      const subIncome = v.subs * 2.5 // ~$2.50 per sub to streamer
      const bitIncome = v.bits * 0.01
      return [
        { label: "Monthly Income", value: usd2(subIncome + bitIncome), highlight: true },
        { label: "From Subs", value: usd2(subIncome) },
        { label: "From Bits", value: usd2(bitIncome) },
      ]
    },
  },
  "freelance-rate": {
    intro: "Find the hourly rate you need to hit your income goal.",
    fields: [
      { key: "goal", label: "Target Annual Income", type: "currency", default: 90000 },
      { key: "billable", label: "Billable Hours / Week", type: "number", default: 25, suffix: "hrs" },
      { key: "weeks", label: "Working Weeks / Year", type: "number", default: 48, suffix: "wks" },
      { key: "expenses", label: "Annual Expenses", type: "currency", default: 12000 },
    ],
    compute: (v) => {
      const hours = v.billable * v.weeks
      const rate = (v.goal + v.expenses) / hours
      return [
        { label: "Hourly Rate Needed", value: usd2(rate), highlight: true },
        { label: "Day Rate (8h)", value: usd(rate * 8) },
        { label: "Billable Hours / Year", value: num(hours) },
      ]
    },
  },
  patreon: {
    intro: "Estimate net monthly income from Patreon patrons.",
    fields: [
      { key: "patrons", label: "Patrons", type: "number", default: 300, suffix: "patrons" },
      { key: "avgPledge", label: "Average Pledge", type: "currency", default: 8 },
      { key: "feePct", label: "Platform + Fees", type: "percent", default: 12 },
    ],
    compute: (v) => {
      const gross = v.patrons * v.avgPledge
      const net = gross * (1 - v.feePct / 100)
      return [
        { label: "Net Monthly Income", value: usd2(net), highlight: true },
        { label: "Gross", value: usd2(gross) },
        { label: "Yearly", value: usd(net * 12) },
      ]
    },
  },
  newsletter: {
    intro: "Estimate revenue from paid newsletter subscribers.",
    fields: [
      { key: "subs", label: "Paid Subscribers", type: "number", default: 1000, suffix: "subs" },
      { key: "price", label: "Monthly Price", type: "currency", default: 7 },
      { key: "feePct", label: "Platform Fee", type: "percent", default: 10 },
    ],
    compute: (v) => {
      const net = v.subs * v.price * (1 - v.feePct / 100)
      return [
        { label: "Net Monthly Revenue", value: usd(net), highlight: true },
        { label: "Annual Revenue", value: usd(net * 12) },
      ]
    },
  },

  "crypto-profit": {
    intro: "Calculate profit or loss from a crypto trade.",
    fields: [
      { key: "amount", label: "Amount Invested", type: "currency", default: 5000 },
      { key: "buy", label: "Buy Price", type: "currency", default: 30000 },
      { key: "sell", label: "Sell Price", type: "currency", default: 45000 },
    ],
    compute: (v) => {
      const coins = v.amount / v.buy
      const proceeds = coins * v.sell
      const profit = proceeds - v.amount
      return [
        { label: "Profit / Loss", value: usd2(profit), highlight: true },
        { label: "Return", value: pct((profit / v.amount) * 100) },
        { label: "Final Value", value: usd2(proceeds) },
      ]
    },
  },
  "staking-rewards": {
    intro: "Estimate annual rewards from staking crypto.",
    fields: [
      { key: "amount", label: "Amount Staked", type: "currency", default: 10000 },
      { key: "apy", label: "Staking APY", type: "percent", default: 6 },
      { key: "years", label: "Years", type: "number", default: 3, suffix: "yrs" },
    ],
    compute: (v) => {
      const fv = v.amount * Math.pow(1 + v.apy / 100, v.years)
      return [
        { label: "Total Value", value: usd2(fv), highlight: true },
        { label: "Rewards Earned", value: usd2(fv - v.amount) },
        { label: "First-Year Rewards", value: usd2(v.amount * (v.apy / 100)) },
      ]
    },
  },
  "bitcoin-dca": {
    intro: "Project the value of recurring crypto buys over time.",
    fields: [
      { key: "monthly", label: "Monthly Buy", type: "currency", default: 200 },
      { key: "rate", label: "Assumed Annual Growth", type: "percent", default: 15 },
      { key: "years", label: "Years", type: "number", default: 5, suffix: "yrs" },
    ],
    compute: (v) => {
      const r = v.rate / 100 / 12
      const n = v.years * 12
      const fv = r === 0 ? v.monthly * n : v.monthly * ((Math.pow(1 + r, n) - 1) / r)
      return [
        { label: "Projected Value", value: usd(fv), highlight: true },
        { label: "Total Invested", value: usd(v.monthly * n) },
        { label: "Potential Gains", value: usd(fv - v.monthly * n) },
      ]
    },
  },
  "mining-profit": {
    intro: "Estimate daily mining profit after electricity costs.",
    fields: [
      { key: "revenue", label: "Daily Revenue", type: "currency", default: 12 },
      { key: "power", label: "Power Draw", type: "number", default: 1500, suffix: "watts" },
      { key: "cost", label: "Electricity Cost", type: "currency", default: 0.12, step: 0.01, suffix: "/kWh" },
    ],
    compute: (v) => {
      const kwhDay = (v.power / 1000) * 24
      const elecCost = kwhDay * v.cost
      const profit = v.revenue - elecCost
      return [
        { label: "Daily Profit", value: usd2(profit), highlight: true },
        { label: "Monthly Profit", value: usd2(profit * 30) },
        { label: "Daily Electricity", value: usd2(elecCost) },
      ]
    },
  },
  "crypto-portfolio": {
    intro: "Calculate total value and gain of your holdings.",
    fields: [
      { key: "coins", label: "Coins Held", type: "number", default: 0.5, step: 0.0001 },
      { key: "avgCost", label: "Avg Cost / Coin", type: "currency", default: 25000 },
      { key: "price", label: "Current Price", type: "currency", default: 40000 },
    ],
    compute: (v) => {
      const value = v.coins * v.price
      const cost = v.coins * v.avgCost
      return [
        { label: "Portfolio Value", value: usd2(value), highlight: true },
        { label: "Unrealized Gain", value: usd2(value - cost) },
        { label: "Return", value: pct(((value - cost) / cost) * 100) },
      ]
    },
  },

  "profit-margin": {
    intro: "Calculate profit margin and markup from cost and price.",
    fields: [
      { key: "cost", label: "Cost", type: "currency", default: 40 },
      { key: "price", label: "Selling Price", type: "currency", default: 100 },
    ],
    compute: (v) => {
      const profit = v.price - v.cost
      return [
        { label: "Profit Margin", value: pct((profit / v.price) * 100), highlight: true },
        { label: "Markup", value: pct((profit / v.cost) * 100) },
        { label: "Profit per Unit", value: usd2(profit) },
      ]
    },
  },
  "break-even": {
    intro: "Find how many units you need to sell to break even.",
    fields: [
      { key: "fixed", label: "Fixed Costs", type: "currency", default: 10000 },
      { key: "price", label: "Price per Unit", type: "currency", default: 50 },
      { key: "variable", label: "Variable Cost / Unit", type: "currency", default: 20 },
    ],
    compute: (v) => {
      const margin = v.price - v.variable
      const units = v.fixed / margin
      return [
        { label: "Break-Even Units", value: num(Math.ceil(units)), highlight: true },
        { label: "Break-Even Revenue", value: usd(units * v.price) },
        { label: "Contribution Margin", value: usd2(margin) },
      ]
    },
  },
  markup: {
    intro: "Calculate the selling price from cost and markup.",
    fields: [
      { key: "cost", label: "Cost", type: "currency", default: 50 },
      { key: "markup", label: "Markup", type: "percent", default: 60 },
    ],
    compute: (v) => {
      const price = v.cost * (1 + v.markup / 100)
      return [
        { label: "Selling Price", value: usd2(price), highlight: true },
        { label: "Profit", value: usd2(price - v.cost) },
      ]
    },
  },
  "ltv-cac": {
    intro: "Measure customer lifetime value against acquisition cost.",
    fields: [
      { key: "arpu", label: "Avg Revenue / Month", type: "currency", default: 50 },
      { key: "margin", label: "Gross Margin", type: "percent", default: 70 },
      { key: "lifetime", label: "Avg Lifetime", type: "number", default: 24, suffix: "mo" },
      { key: "cac", label: "Acquisition Cost", type: "currency", default: 300 },
    ],
    compute: (v) => {
      const ltv = v.arpu * (v.margin / 100) * v.lifetime
      return [
        { label: "LTV : CAC", value: `${(ltv / v.cac).toFixed(1)} : 1`, highlight: true },
        { label: "Lifetime Value", value: usd(ltv) },
        { label: "Payback Period", value: `${(v.cac / (v.arpu * (v.margin / 100))).toFixed(1)} mo` },
      ]
    },
  },
  discount: {
    intro: "Find the final price after applying a discount.",
    fields: [
      { key: "price", label: "Original Price", type: "currency", default: 120 },
      { key: "discount", label: "Discount", type: "percent", default: 25 },
    ],
    compute: (v) => {
      const saved = v.price * (v.discount / 100)
      return [
        { label: "Final Price", value: usd2(v.price - saved), highlight: true },
        { label: "You Save", value: usd2(saved) },
      ]
    },
  },
  "invoice-total": {
    intro: "Calculate an invoice total with tax and discount.",
    fields: [
      { key: "subtotal", label: "Subtotal", type: "currency", default: 2500 },
      { key: "discount", label: "Discount", type: "percent", default: 10 },
      { key: "tax", label: "Tax Rate", type: "percent", default: 8 },
    ],
    compute: (v) => {
      const afterDiscount = v.subtotal * (1 - v.discount / 100)
      const tax = afterDiscount * (v.tax / 100)
      return [
        { label: "Invoice Total", value: usd2(afterDiscount + tax), highlight: true },
        { label: "After Discount", value: usd2(afterDiscount) },
        { label: "Tax", value: usd2(tax) },
      ]
    },
  },
}

export function getCalculator(id: string): Calculator | null {
  return calculators[id] ?? null
}
