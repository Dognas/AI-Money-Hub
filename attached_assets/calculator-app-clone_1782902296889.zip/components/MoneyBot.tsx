"use client"

import { useState, useRef, useEffect } from "react"
import { allTools } from "@/data/calculators"

type Message = {
  role: "bot" | "user"
  text: string
  tools?: { id: string; name: string; icon: string }[]
}

const QUICK_PROMPTS = [
  "Calculate my take-home pay",
  "How does compound interest work?",
  "Estimate my mortgage payment",
  "How much do YouTubers earn?",
]

function findTools(query: string) {
  const q = query.toLowerCase()
  const words = q.split(/\s+/).filter((w) => w.length > 2)
  return allTools
    .map((t) => {
      const hay = `${t.name} ${t.desc} ${t.category}`.toLowerCase()
      let score = 0
      for (const w of words) if (hay.includes(w)) score += 1
      return { t, score }
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((r) => ({ id: r.t.id, name: r.t.name, icon: r.t.icon }))
}

function botReply(query: string): Message {
  const q = query.toLowerCase()
  const tools = findTools(query)

  let text = ""
  if (/(compound|interest)/.test(q)) {
    text =
      "Compound interest is interest earned on both your original money and the interest it has already earned. Over time, it snowballs — which is why investing early matters so much. Try the calculator below to project your growth."
  } else if (/(tax|irs|deduction)/.test(q)) {
    text =
      "Taxes depend on your income, filing status, and deductions. My tax calculators give quick estimates using current brackets. Pick one below to get started."
  } else if (/(mortgage|home|house|loan)/.test(q)) {
    text =
      "For a loan, your monthly payment depends on the principal, interest rate, and term. Use the calculators below for an instant estimate including total interest."
  } else if (/(youtube|tiktok|instagram|creator|twitch|influencer)/.test(q)) {
    text =
      "Creator earnings depend on views, CPM/RPM, and your audience engagement. These calculators give realistic ballpark numbers based on industry averages."
  } else if (/(retire|fire|401|pension)/.test(q)) {
    text =
      "Retirement planning comes down to how much you save and how long it compounds. The FIRE and 401(k) calculators below can map out your path."
  } else if (/(save|saving|budget|emergency)/.test(q)) {
    text =
      "A solid plan starts with budgeting and an emergency fund. Try the tools below to set realistic monthly targets."
  } else if (tools.length > 0) {
    text = "Great question! Based on what you asked, here are the calculators I'd recommend:"
  } else {
    text =
      "I can help with salaries, taxes, investing, loans, savings, crypto, and creator income. Try asking about a specific topic, or browse the 120+ calculators above."
  }

  return { role: "bot", text, tools: tools.length ? tools : undefined }
}

export default function MoneyBot({ darkMode }: { darkMode: boolean }) {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "bot",
      text: "Hi! I'm MoneyBot 🤖 — your AI money assistant. Ask me anything about your finances, or tap a suggestion to begin.",
    },
  ])
  const [typing, setTyping] = useState(false)
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, typing, open])

  const send = (text: string) => {
    const trimmed = text.trim()
    if (!trimmed) return
    setMessages((m) => [...m, { role: "user", text: trimmed }])
    setInput("")
    setTyping(true)
    setTimeout(() => {
      setMessages((m) => [...m, botReply(trimmed)])
      setTyping(false)
    }, 650)
  }

  const handleKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      e.preventDefault()
      send(input)
    }
  }

  const panelBg = darkMode ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200"
  const headerText = darkMode ? "text-white" : "text-gray-900"
  const botBubble = darkMode ? "bg-gray-800 text-gray-100" : "bg-gray-100 text-gray-800"

  return (
    <>
      {/* Toggle button */}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? "Close MoneyBot" : "Open MoneyBot AI assistant"}
        className="fixed bottom-5 right-5 z-50 w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-2xl transition-transform hover:scale-110 btn-gradient text-white"
      >
        {open ? "✕" : "🤖"}
      </button>

      {/* Chat panel */}
      {open && (
        <div
          className={`fixed bottom-24 right-5 z-50 w-[calc(100vw-2.5rem)] sm:w-96 max-h-[70vh] rounded-3xl border shadow-2xl flex flex-col overflow-hidden ${panelBg}`}
        >
          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 btn-gradient text-white flex-shrink-0">
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-lg">🤖</div>
            <div className="min-w-0">
              <div className="font-bold text-sm leading-tight">MoneyBot AI</div>
              <div className="text-xs text-white/80 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-green-300 inline-block" />
                Online · Ask me anything
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className="max-w-[85%]">
                  <div
                    className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                      m.role === "user" ? "btn-gradient text-white rounded-br-sm" : `${botBubble} rounded-bl-sm`
                    }`}
                  >
                    {m.text}
                  </div>
                  {m.tools && (
                    <div className="mt-2 space-y-1.5">
                      {m.tools.map((t) => (
                        <a
                          key={t.id}
                          href={`/calculator/${t.id}`}
                          className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold transition-colors ${
                            darkMode
                              ? "border-gray-700 bg-gray-800 text-gray-100 hover:border-emerald-500/50"
                              : "border-gray-200 bg-white text-gray-800 hover:border-emerald-300"
                          }`}
                        >
                          <span className="text-base">{t.icon}</span>
                          {t.name}
                          <span className="ml-auto text-emerald-500">→</span>
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {typing && (
              <div className="flex justify-start">
                <div className={`px-4 py-3 rounded-2xl rounded-bl-sm ${botBubble}`}>
                  <div className="flex gap-1">
                    <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Quick prompts */}
          {messages.length <= 1 && (
            <div className="px-4 pb-2 flex flex-wrap gap-2 flex-shrink-0">
              {QUICK_PROMPTS.map((p) => (
                <button
                  key={p}
                  onClick={() => send(p)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                    darkMode
                      ? "border-gray-700 text-gray-300 hover:bg-gray-800"
                      : "border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className={`p-3 border-t flex items-center gap-2 flex-shrink-0 ${darkMode ? "border-gray-800" : "border-gray-100"}`}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Ask about money..."
              className={`flex-1 text-sm outline-none rounded-xl px-3 py-2.5 border ${
                darkMode
                  ? "bg-gray-800 border-gray-700 text-white placeholder-gray-500"
                  : "bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400"
              }`}
            />
            <button
              onClick={() => send(input)}
              aria-label="Send message"
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white btn-gradient flex-shrink-0 transition-transform hover:scale-105"
            >
              ➤
            </button>
          </div>
        </div>
      )}
    </>
  )
}
